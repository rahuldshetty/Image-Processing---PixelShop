﻿namespace PixWork
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea19 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series19 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea20 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series20 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea21 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series21 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.trackBar1 = new MetroFramework.Controls.MetroTrackBar();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.trackBar2 = new MetroFramework.Controls.MetroTrackBar();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.tabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLink10 = new MetroFramework.Controls.MetroLink();
            this.metroLink9 = new MetroFramework.Controls.MetroLink();
            this.metroLink8 = new MetroFramework.Controls.MetroLink();
            this.metroToggle3 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle2 = new MetroFramework.Controls.MetroToggle();
            this.metroToggle1 = new MetroFramework.Controls.MetroToggle();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.File = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.openImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Edit = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.undoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.View = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.nextTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previousTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Image = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.rotateToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cWToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cCWToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.flipToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.horizontalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.verticalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.grayscaleToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.skeletonizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Filters = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.blurToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.boxMeanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gaussian3X3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gaussian5X5ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sharpenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.mediumToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.highToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.edgesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lowToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.highToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.sobelHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sobelVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.prewittToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.embossToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.laplacianToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.laplacianOfGaussianToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Adjustments = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.histogramEquilizationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.invertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dilationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.erosionToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.x5ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.closeToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.Help = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.aboutToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.metroLink6 = new MetroFramework.Controls.MetroLink();
            this.metroLink7 = new MetroFramework.Controls.MetroLink();
            this.metroLink5 = new MetroFramework.Controls.MetroLink();
            this.metroLink4 = new MetroFramework.Controls.MetroLink();
            this.metroLink3 = new MetroFramework.Controls.MetroLink();
            this.metroLink2 = new MetroFramework.Controls.MetroLink();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.metroPanel4 = new MetroFramework.Controls.MetroPanel();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.histogramEquilizationColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.metroPanel1.SuspendLayout();
            this.metroPanel2.SuspendLayout();
            this.File.SuspendLayout();
            this.Edit.SuspendLayout();
            this.View.SuspendLayout();
            this.Image.SuspendLayout();
            this.Filters.SuspendLayout();
            this.Adjustments.SuspendLayout();
            this.Help.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            this.metroPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            chartArea19.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea19);
            this.chart1.Location = new System.Drawing.Point(102, 145);
            this.chart1.Name = "chart1";
            series19.ChartArea = "ChartArea1";
            series19.MarkerSize = 3;
            series19.Name = "Series1";
            this.chart1.Series.Add(series19);
            this.chart1.Size = new System.Drawing.Size(108, 98);
            this.chart1.TabIndex = 4;
            this.chart1.Text = "chart1";
            this.chart1.Click += new System.EventHandler(this.chart1_Click);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(80, 49);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(58, 19);
            this.metroLabel1.TabIndex = 6;
            this.metroLabel1.Text = "Contrast";
            this.metroLabel1.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.BackColor = System.Drawing.Color.Transparent;
            this.trackBar1.Location = new System.Drawing.Point(16, 25);
            this.trackBar1.Maximum = 255;
            this.trackBar1.Minimum = -255;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(186, 23);
            this.trackBar1.TabIndex = 7;
            this.trackBar1.Text = "Brightness";
            this.trackBar1.Value = 0;
            this.trackBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.trackBar1_Scroll);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(75, 3);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(68, 19);
            this.metroLabel2.TabIndex = 6;
            this.metroLabel2.Text = "Brightness";
            this.metroLabel2.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // trackBar2
            // 
            this.trackBar2.BackColor = System.Drawing.Color.Transparent;
            this.trackBar2.Location = new System.Drawing.Point(16, 71);
            this.trackBar2.Minimum = -100;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(186, 23);
            this.trackBar2.TabIndex = 7;
            this.trackBar2.Text = "Contrast";
            this.trackBar2.Value = 0;
            this.trackBar2.Scroll += new System.Windows.Forms.ScrollEventHandler(this.trackBar2_Scroll);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(73, 108);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(70, 19);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "Histogram";
            this.metroLabel3.Click += new System.EventHandler(this.metroLabel1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Size = new System.Drawing.Size(973, 586);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.UseSelectable = true;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged_1);
            // 
            // metroPanel1
            // 
            this.metroPanel1.Controls.Add(this.metroLink10);
            this.metroPanel1.Controls.Add(this.metroLink9);
            this.metroPanel1.Controls.Add(this.metroLink8);
            this.metroPanel1.Controls.Add(this.metroToggle3);
            this.metroPanel1.Controls.Add(this.metroToggle2);
            this.metroPanel1.Controls.Add(this.metroToggle1);
            this.metroPanel1.Controls.Add(this.chart3);
            this.metroPanel1.Controls.Add(this.chart2);
            this.metroPanel1.Controls.Add(this.chart1);
            this.metroPanel1.Controls.Add(this.metroLabel3);
            this.metroPanel1.Controls.Add(this.trackBar2);
            this.metroPanel1.Controls.Add(this.trackBar1);
            this.metroPanel1.Controls.Add(this.metroLabel1);
            this.metroPanel1.Controls.Add(this.metroLabel2);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(973, 0);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(224, 586);
            this.metroPanel1.TabIndex = 8;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // metroLink10
            // 
            this.metroLink10.Location = new System.Drawing.Point(38, 249);
            this.metroLink10.Name = "metroLink10";
            this.metroLink10.Size = new System.Drawing.Size(58, 23);
            this.metroLink10.TabIndex = 9;
            this.metroLink10.Text = "Green";
            this.metroLink10.UseSelectable = true;
            this.metroLink10.Click += new System.EventHandler(this.metroLink10_Click);
            // 
            // metroLink9
            // 
            this.metroLink9.Location = new System.Drawing.Point(30, 385);
            this.metroLink9.Name = "metroLink9";
            this.metroLink9.Size = new System.Drawing.Size(58, 23);
            this.metroLink9.TabIndex = 9;
            this.metroLink9.Text = "Blue";
            this.metroLink9.UseSelectable = true;
            // 
            // metroLink8
            // 
            this.metroLink8.Location = new System.Drawing.Point(30, 145);
            this.metroLink8.Name = "metroLink8";
            this.metroLink8.Size = new System.Drawing.Size(58, 23);
            this.metroLink8.TabIndex = 9;
            this.metroLink8.Text = "Red";
            this.metroLink8.UseSelectable = true;
            this.metroLink8.Click += new System.EventHandler(this.metroLink8_Click);
            // 
            // metroToggle3
            // 
            this.metroToggle3.AutoSize = true;
            this.metroToggle3.Checked = true;
            this.metroToggle3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.metroToggle3.Location = new System.Drawing.Point(16, 430);
            this.metroToggle3.Name = "metroToggle3";
            this.metroToggle3.Size = new System.Drawing.Size(80, 17);
            this.metroToggle3.TabIndex = 8;
            this.metroToggle3.Text = "On";
            this.metroToggle3.UseSelectable = true;
            this.metroToggle3.CheckedChanged += new System.EventHandler(this.metroToggle3_CheckedChanged);
            // 
            // metroToggle2
            // 
            this.metroToggle2.AutoSize = true;
            this.metroToggle2.Checked = true;
            this.metroToggle2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.metroToggle2.Location = new System.Drawing.Point(16, 301);
            this.metroToggle2.Name = "metroToggle2";
            this.metroToggle2.Size = new System.Drawing.Size(80, 17);
            this.metroToggle2.TabIndex = 8;
            this.metroToggle2.Text = "On";
            this.metroToggle2.UseSelectable = true;
            this.metroToggle2.CheckedChanged += new System.EventHandler(this.metroToggle2_CheckedChanged);
            // 
            // metroToggle1
            // 
            this.metroToggle1.AutoSize = true;
            this.metroToggle1.Checked = true;
            this.metroToggle1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.metroToggle1.Location = new System.Drawing.Point(16, 188);
            this.metroToggle1.Name = "metroToggle1";
            this.metroToggle1.Size = new System.Drawing.Size(80, 17);
            this.metroToggle1.TabIndex = 8;
            this.metroToggle1.Text = "On";
            this.metroToggle1.UseSelectable = true;
            this.metroToggle1.CheckedChanged += new System.EventHandler(this.metroToggle1_CheckedChanged);
            // 
            // metroPanel2
            // 
            this.metroPanel2.Controls.Add(this.tabControl1);
            this.metroPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(0, 0);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(973, 586);
            this.metroPanel2.TabIndex = 9;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // File
            // 
            this.File.BackColor = System.Drawing.SystemColors.Control;
            this.File.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openImageToolStripMenuItem,
            this.saveAsToolStripMenuItem1,
            this.closeToolStripMenuItem2,
            this.exitToolStripMenuItem1});
            this.File.Name = "File";
            this.File.Size = new System.Drawing.Size(183, 92);
            this.File.Theme = MetroFramework.MetroThemeStyle.Light;
            this.File.UseCustomBackColor = true;
            this.File.UseCustomForeColor = true;
            this.File.UseStyleColors = true;
            // 
            // openImageToolStripMenuItem
            // 
            this.openImageToolStripMenuItem.Name = "openImageToolStripMenuItem";
            this.openImageToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openImageToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.openImageToolStripMenuItem.Text = "Open Image";
            this.openImageToolStripMenuItem.Click += new System.EventHandler(this.openImageToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem1
            // 
            this.saveAsToolStripMenuItem1.Name = "saveAsToolStripMenuItem1";
            this.saveAsToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveAsToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.saveAsToolStripMenuItem1.Text = "Save As";
            this.saveAsToolStripMenuItem1.Click += new System.EventHandler(this.saveAsToolStripMenuItem1_Click);
            // 
            // closeToolStripMenuItem2
            // 
            this.closeToolStripMenuItem2.Name = "closeToolStripMenuItem2";
            this.closeToolStripMenuItem2.Size = new System.Drawing.Size(182, 22);
            this.closeToolStripMenuItem2.Text = "Close";
            this.closeToolStripMenuItem2.Click += new System.EventHandler(this.closeToolStripMenuItem2_Click);
            // 
            // exitToolStripMenuItem1
            // 
            this.exitToolStripMenuItem1.Name = "exitToolStripMenuItem1";
            this.exitToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.exitToolStripMenuItem1.Size = new System.Drawing.Size(182, 22);
            this.exitToolStripMenuItem1.Text = "Exit";
            this.exitToolStripMenuItem1.Click += new System.EventHandler(this.exitToolStripMenuItem1_Click);
            // 
            // Edit
            // 
            this.Edit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem1});
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(145, 26);
            this.Edit.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Edit.UseStyleColors = true;
            // 
            // undoToolStripMenuItem1
            // 
            this.undoToolStripMenuItem1.Name = "undoToolStripMenuItem1";
            this.undoToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undoToolStripMenuItem1.Size = new System.Drawing.Size(144, 22);
            this.undoToolStripMenuItem1.Text = "Undo";
            this.undoToolStripMenuItem1.Click += new System.EventHandler(this.undoToolStripMenuItem1_Click);
            // 
            // View
            // 
            this.View.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nextTabToolStripMenuItem,
            this.previousTabToolStripMenuItem});
            this.View.Name = "View";
            this.View.Size = new System.Drawing.Size(227, 48);
            this.View.Theme = MetroFramework.MetroThemeStyle.Light;
            this.View.UseStyleColors = true;
            // 
            // nextTabToolStripMenuItem
            // 
            this.nextTabToolStripMenuItem.Name = "nextTabToolStripMenuItem";
            this.nextTabToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Tab)));
            this.nextTabToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.nextTabToolStripMenuItem.Text = "Next Tab";
            this.nextTabToolStripMenuItem.Click += new System.EventHandler(this.nextTabToolStripMenuItem_Click);
            // 
            // previousTabToolStripMenuItem
            // 
            this.previousTabToolStripMenuItem.Name = "previousTabToolStripMenuItem";
            this.previousTabToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.Tab)));
            this.previousTabToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.previousTabToolStripMenuItem.Text = "Previous Tab";
            this.previousTabToolStripMenuItem.Click += new System.EventHandler(this.previousTabToolStripMenuItem_Click);
            // 
            // Image
            // 
            this.Image.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.rotateToolStripMenuItem1,
            this.flipToolStripMenuItem1,
            this.grayscaleToolStripMenuItem1,
            this.skeletonizeToolStripMenuItem});
            this.Image.Name = "Image";
            this.Image.Size = new System.Drawing.Size(126, 92);
            this.Image.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Image.UseStyleColors = true;
            // 
            // rotateToolStripMenuItem1
            // 
            this.rotateToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cWToolStripMenuItem1,
            this.cCWToolStripMenuItem1});
            this.rotateToolStripMenuItem1.Name = "rotateToolStripMenuItem1";
            this.rotateToolStripMenuItem1.Size = new System.Drawing.Size(125, 22);
            this.rotateToolStripMenuItem1.Text = "Rotate";
            // 
            // cWToolStripMenuItem1
            // 
            this.cWToolStripMenuItem1.Name = "cWToolStripMenuItem1";
            this.cWToolStripMenuItem1.Size = new System.Drawing.Size(121, 22);
            this.cWToolStripMenuItem1.Text = "90* CW";
            this.cWToolStripMenuItem1.Click += new System.EventHandler(this.cWToolStripMenuItem1_Click);
            // 
            // cCWToolStripMenuItem1
            // 
            this.cCWToolStripMenuItem1.Name = "cCWToolStripMenuItem1";
            this.cCWToolStripMenuItem1.Size = new System.Drawing.Size(121, 22);
            this.cCWToolStripMenuItem1.Text = "90* CCW";
            this.cCWToolStripMenuItem1.Click += new System.EventHandler(this.cCWToolStripMenuItem1_Click);
            // 
            // flipToolStripMenuItem1
            // 
            this.flipToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.horizontalToolStripMenuItem1,
            this.verticalToolStripMenuItem1});
            this.flipToolStripMenuItem1.Name = "flipToolStripMenuItem1";
            this.flipToolStripMenuItem1.Size = new System.Drawing.Size(125, 22);
            this.flipToolStripMenuItem1.Text = "Flip";
            // 
            // horizontalToolStripMenuItem1
            // 
            this.horizontalToolStripMenuItem1.Name = "horizontalToolStripMenuItem1";
            this.horizontalToolStripMenuItem1.Size = new System.Drawing.Size(129, 22);
            this.horizontalToolStripMenuItem1.Text = "Horizontal";
            this.horizontalToolStripMenuItem1.Click += new System.EventHandler(this.horizontalToolStripMenuItem1_Click);
            // 
            // verticalToolStripMenuItem1
            // 
            this.verticalToolStripMenuItem1.Name = "verticalToolStripMenuItem1";
            this.verticalToolStripMenuItem1.Size = new System.Drawing.Size(129, 22);
            this.verticalToolStripMenuItem1.Text = "Vertical";
            this.verticalToolStripMenuItem1.Click += new System.EventHandler(this.verticalToolStripMenuItem1_Click);
            // 
            // grayscaleToolStripMenuItem1
            // 
            this.grayscaleToolStripMenuItem1.Name = "grayscaleToolStripMenuItem1";
            this.grayscaleToolStripMenuItem1.Size = new System.Drawing.Size(125, 22);
            this.grayscaleToolStripMenuItem1.Text = "Grayscale";
            this.grayscaleToolStripMenuItem1.Click += new System.EventHandler(this.grayscaleToolStripMenuItem1_Click);
            // 
            // skeletonizeToolStripMenuItem
            // 
            this.skeletonizeToolStripMenuItem.Name = "skeletonizeToolStripMenuItem";
            this.skeletonizeToolStripMenuItem.Size = new System.Drawing.Size(125, 22);
            this.skeletonizeToolStripMenuItem.Text = "Perimeter";
            this.skeletonizeToolStripMenuItem.Click += new System.EventHandler(this.skeletonizeToolStripMenuItem_Click);
            // 
            // Filters
            // 
            this.Filters.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blurToolStripMenuItem1,
            this.sharpenToolStripMenuItem,
            this.edgesToolStripMenuItem,
            this.embossToolStripMenuItem1,
            this.laplacianToolStripMenuItem1,
            this.laplacianOfGaussianToolStripMenuItem1});
            this.Filters.Name = "Filters";
            this.Filters.Size = new System.Drawing.Size(189, 136);
            this.Filters.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Filters.UseStyleColors = true;
            // 
            // blurToolStripMenuItem1
            // 
            this.blurToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.boxMeanToolStripMenuItem,
            this.gaussian3X3ToolStripMenuItem,
            this.gaussian5X5ToolStripMenuItem1});
            this.blurToolStripMenuItem1.Name = "blurToolStripMenuItem1";
            this.blurToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.blurToolStripMenuItem1.Text = "Blur";
            // 
            // boxMeanToolStripMenuItem
            // 
            this.boxMeanToolStripMenuItem.Name = "boxMeanToolStripMenuItem";
            this.boxMeanToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.boxMeanToolStripMenuItem.Text = "Box ( Mean )";
            this.boxMeanToolStripMenuItem.Click += new System.EventHandler(this.boxMeanToolStripMenuItem_Click);
            // 
            // gaussian3X3ToolStripMenuItem
            // 
            this.gaussian3X3ToolStripMenuItem.Name = "gaussian3X3ToolStripMenuItem";
            this.gaussian3X3ToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.gaussian3X3ToolStripMenuItem.Text = "Gaussian ( 3 x 3 )";
            this.gaussian3X3ToolStripMenuItem.Click += new System.EventHandler(this.gaussian3X3ToolStripMenuItem_Click);
            // 
            // gaussian5X5ToolStripMenuItem1
            // 
            this.gaussian5X5ToolStripMenuItem1.Name = "gaussian5X5ToolStripMenuItem1";
            this.gaussian5X5ToolStripMenuItem1.Size = new System.Drawing.Size(164, 22);
            this.gaussian5X5ToolStripMenuItem1.Text = "Gaussian (  5 x 5 )";
            this.gaussian5X5ToolStripMenuItem1.Click += new System.EventHandler(this.gaussian5X5ToolStripMenuItem1_Click);
            // 
            // sharpenToolStripMenuItem
            // 
            this.sharpenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lowToolStripMenuItem1,
            this.mediumToolStripMenuItem1,
            this.highToolStripMenuItem1});
            this.sharpenToolStripMenuItem.Name = "sharpenToolStripMenuItem";
            this.sharpenToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.sharpenToolStripMenuItem.Text = "Sharpen";
            // 
            // lowToolStripMenuItem1
            // 
            this.lowToolStripMenuItem1.Name = "lowToolStripMenuItem1";
            this.lowToolStripMenuItem1.Size = new System.Drawing.Size(119, 22);
            this.lowToolStripMenuItem1.Text = "Low";
            this.lowToolStripMenuItem1.Click += new System.EventHandler(this.lowToolStripMenuItem1_Click);
            // 
            // mediumToolStripMenuItem1
            // 
            this.mediumToolStripMenuItem1.Name = "mediumToolStripMenuItem1";
            this.mediumToolStripMenuItem1.Size = new System.Drawing.Size(119, 22);
            this.mediumToolStripMenuItem1.Text = "Medium";
            this.mediumToolStripMenuItem1.Click += new System.EventHandler(this.mediumToolStripMenuItem1_Click);
            // 
            // highToolStripMenuItem1
            // 
            this.highToolStripMenuItem1.Name = "highToolStripMenuItem1";
            this.highToolStripMenuItem1.Size = new System.Drawing.Size(119, 22);
            this.highToolStripMenuItem1.Text = "High";
            this.highToolStripMenuItem1.Click += new System.EventHandler(this.highToolStripMenuItem1_Click);
            // 
            // edgesToolStripMenuItem
            // 
            this.edgesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lowToolStripMenuItem2,
            this.highToolStripMenuItem2,
            this.sobelHorizontalToolStripMenuItem,
            this.sobelVerticalToolStripMenuItem,
            this.prewittToolStripMenuItem});
            this.edgesToolStripMenuItem.Name = "edgesToolStripMenuItem";
            this.edgesToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.edgesToolStripMenuItem.Text = "Edges";
            // 
            // lowToolStripMenuItem2
            // 
            this.lowToolStripMenuItem2.Name = "lowToolStripMenuItem2";
            this.lowToolStripMenuItem2.Size = new System.Drawing.Size(175, 22);
            this.lowToolStripMenuItem2.Text = "Low";
            this.lowToolStripMenuItem2.Click += new System.EventHandler(this.lowToolStripMenuItem2_Click);
            // 
            // highToolStripMenuItem2
            // 
            this.highToolStripMenuItem2.Name = "highToolStripMenuItem2";
            this.highToolStripMenuItem2.Size = new System.Drawing.Size(175, 22);
            this.highToolStripMenuItem2.Text = "High";
            this.highToolStripMenuItem2.Click += new System.EventHandler(this.highToolStripMenuItem2_Click);
            // 
            // sobelHorizontalToolStripMenuItem
            // 
            this.sobelHorizontalToolStripMenuItem.Name = "sobelHorizontalToolStripMenuItem";
            this.sobelHorizontalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.sobelHorizontalToolStripMenuItem.Text = "Sobel ( Horizontal )";
            this.sobelHorizontalToolStripMenuItem.Click += new System.EventHandler(this.sobelHorizontalToolStripMenuItem_Click);
            // 
            // sobelVerticalToolStripMenuItem
            // 
            this.sobelVerticalToolStripMenuItem.Name = "sobelVerticalToolStripMenuItem";
            this.sobelVerticalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.sobelVerticalToolStripMenuItem.Text = "Sobel ( Vertical )";
            this.sobelVerticalToolStripMenuItem.Click += new System.EventHandler(this.sobelVerticalToolStripMenuItem_Click);
            // 
            // prewittToolStripMenuItem
            // 
            this.prewittToolStripMenuItem.Name = "prewittToolStripMenuItem";
            this.prewittToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.prewittToolStripMenuItem.Text = "Prewitt";
            this.prewittToolStripMenuItem.Click += new System.EventHandler(this.prewittToolStripMenuItem_Click);
            // 
            // embossToolStripMenuItem1
            // 
            this.embossToolStripMenuItem1.Name = "embossToolStripMenuItem1";
            this.embossToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.embossToolStripMenuItem1.Text = "Emboss";
            this.embossToolStripMenuItem1.Click += new System.EventHandler(this.embossToolStripMenuItem1_Click);
            // 
            // laplacianToolStripMenuItem1
            // 
            this.laplacianToolStripMenuItem1.Name = "laplacianToolStripMenuItem1";
            this.laplacianToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.laplacianToolStripMenuItem1.Text = "Laplacian";
            this.laplacianToolStripMenuItem1.Click += new System.EventHandler(this.laplacianToolStripMenuItem1_Click);
            // 
            // laplacianOfGaussianToolStripMenuItem1
            // 
            this.laplacianOfGaussianToolStripMenuItem1.Name = "laplacianOfGaussianToolStripMenuItem1";
            this.laplacianOfGaussianToolStripMenuItem1.Size = new System.Drawing.Size(188, 22);
            this.laplacianOfGaussianToolStripMenuItem1.Text = "Laplacian of Gaussian";
            this.laplacianOfGaussianToolStripMenuItem1.Click += new System.EventHandler(this.laplacianOfGaussianToolStripMenuItem1_Click);
            // 
            // Adjustments
            // 
            this.Adjustments.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.invertToolStripMenuItem,
            this.dilationToolStripMenuItem1,
            this.erosionToolStripMenuItem1,
            this.openToolStripMenuItem1,
            this.closeToolStripMenuItem3,
            this.histogramEquilizationToolStripMenuItem1,
            this.histogramEquilizationColorToolStripMenuItem});
            this.Adjustments.Name = "Adjustments";
            this.Adjustments.Size = new System.Drawing.Size(227, 158);
            this.Adjustments.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Adjustments.UseStyleColors = true;
            // 
            // histogramEquilizationToolStripMenuItem1
            // 
            this.histogramEquilizationToolStripMenuItem1.Name = "histogramEquilizationToolStripMenuItem1";
            this.histogramEquilizationToolStripMenuItem1.Size = new System.Drawing.Size(226, 22);
            this.histogramEquilizationToolStripMenuItem1.Text = "Histogram Equilization B&W";
            this.histogramEquilizationToolStripMenuItem1.Click += new System.EventHandler(this.histogramEquilizationToolStripMenuItem1_Click);
            // 
            // invertToolStripMenuItem
            // 
            this.invertToolStripMenuItem.Name = "invertToolStripMenuItem";
            this.invertToolStripMenuItem.Size = new System.Drawing.Size(194, 22);
            this.invertToolStripMenuItem.Text = "Invert";
            this.invertToolStripMenuItem.Click += new System.EventHandler(this.invertToolStripMenuItem_Click_1);
            // 
            // dilationToolStripMenuItem1
            // 
            this.dilationToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x3ToolStripMenuItem,
            this.x5ToolStripMenuItem});
            this.dilationToolStripMenuItem1.Name = "dilationToolStripMenuItem1";
            this.dilationToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.dilationToolStripMenuItem1.Text = "Dilation";
            // 
            // x3ToolStripMenuItem
            // 
            this.x3ToolStripMenuItem.Name = "x3ToolStripMenuItem";
            this.x3ToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.x3ToolStripMenuItem.Text = " ( 3 x 3 )";
            this.x3ToolStripMenuItem.Click += new System.EventHandler(this.x3ToolStripMenuItem_Click);
            // 
            // x5ToolStripMenuItem
            // 
            this.x5ToolStripMenuItem.Name = "x5ToolStripMenuItem";
            this.x5ToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.x5ToolStripMenuItem.Text = " ( 5 x 5 ) ";
            this.x5ToolStripMenuItem.Click += new System.EventHandler(this.x5ToolStripMenuItem_Click);
            // 
            // erosionToolStripMenuItem1
            // 
            this.erosionToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x3ToolStripMenuItem1,
            this.x5ToolStripMenuItem1});
            this.erosionToolStripMenuItem1.Name = "erosionToolStripMenuItem1";
            this.erosionToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.erosionToolStripMenuItem1.Text = "Erosion";
            // 
            // x3ToolStripMenuItem1
            // 
            this.x3ToolStripMenuItem1.Name = "x3ToolStripMenuItem1";
            this.x3ToolStripMenuItem1.Size = new System.Drawing.Size(114, 22);
            this.x3ToolStripMenuItem1.Text = " ( 3 x 3 )";
            this.x3ToolStripMenuItem1.Click += new System.EventHandler(this.x3ToolStripMenuItem1_Click);
            // 
            // x5ToolStripMenuItem1
            // 
            this.x5ToolStripMenuItem1.Name = "x5ToolStripMenuItem1";
            this.x5ToolStripMenuItem1.Size = new System.Drawing.Size(114, 22);
            this.x5ToolStripMenuItem1.Text = " ( 5 x 5 )";
            this.x5ToolStripMenuItem1.Click += new System.EventHandler(this.x5ToolStripMenuItem1_Click);
            // 
            // openToolStripMenuItem1
            // 
            this.openToolStripMenuItem1.Name = "openToolStripMenuItem1";
            this.openToolStripMenuItem1.Size = new System.Drawing.Size(194, 22);
            this.openToolStripMenuItem1.Text = "Open";
            this.openToolStripMenuItem1.Click += new System.EventHandler(this.openToolStripMenuItem1_Click);
            // 
            // closeToolStripMenuItem3
            // 
            this.closeToolStripMenuItem3.Name = "closeToolStripMenuItem3";
            this.closeToolStripMenuItem3.Size = new System.Drawing.Size(194, 22);
            this.closeToolStripMenuItem3.Text = "Close";
            this.closeToolStripMenuItem3.Click += new System.EventHandler(this.closeToolStripMenuItem3_Click);
            // 
            // Help
            // 
            this.Help.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem1});
            this.Help.Name = "Help";
            this.Help.Size = new System.Drawing.Size(108, 26);
            this.Help.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Help.UseStyleColors = true;
            // 
            // aboutToolStripMenuItem1
            // 
            this.aboutToolStripMenuItem1.Name = "aboutToolStripMenuItem1";
            this.aboutToolStripMenuItem1.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem1.Text = "About";
            this.aboutToolStripMenuItem1.Click += new System.EventHandler(this.aboutToolStripMenuItem1_Click);
            // 
            // metroPanel3
            // 
            this.metroPanel3.Controls.Add(this.metroLabel4);
            this.metroPanel3.Controls.Add(this.metroLink6);
            this.metroPanel3.Controls.Add(this.metroLink7);
            this.metroPanel3.Controls.Add(this.metroLink5);
            this.metroPanel3.Controls.Add(this.metroLink4);
            this.metroPanel3.Controls.Add(this.metroLink3);
            this.metroPanel3.Controls.Add(this.metroLink2);
            this.metroPanel3.Controls.Add(this.metroLink1);
            this.metroPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(20, 60);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(1197, 28);
            this.metroPanel3.TabIndex = 11;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // metroLink6
            // 
            this.metroLink6.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroLink6.Location = new System.Drawing.Point(480, 0);
            this.metroLink6.Name = "metroLink6";
            this.metroLink6.Size = new System.Drawing.Size(75, 28);
            this.metroLink6.TabIndex = 9;
            this.metroLink6.Text = "Help";
            this.metroLink6.UseSelectable = true;
            this.metroLink6.Click += new System.EventHandler(this.metroLink6_Click_1);
            // 
            // metroLink7
            // 
            this.metroLink7.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroLink7.Location = new System.Drawing.Point(405, 0);
            this.metroLink7.Name = "metroLink7";
            this.metroLink7.Size = new System.Drawing.Size(75, 28);
            this.metroLink7.TabIndex = 8;
            this.metroLink7.Text = "Filters";
            this.metroLink7.UseSelectable = true;
            this.metroLink7.Click += new System.EventHandler(this.metroLink7_Click);
            // 
            // metroLink5
            // 
            this.metroLink5.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroLink5.Location = new System.Drawing.Point(300, 0);
            this.metroLink5.Name = "metroLink5";
            this.metroLink5.Size = new System.Drawing.Size(105, 28);
            this.metroLink5.TabIndex = 6;
            this.metroLink5.Text = "Adjustments";
            this.metroLink5.UseSelectable = true;
            this.metroLink5.Click += new System.EventHandler(this.metroLink5_Click);
            // 
            // metroLink4
            // 
            this.metroLink4.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroLink4.Location = new System.Drawing.Point(225, 0);
            this.metroLink4.Name = "metroLink4";
            this.metroLink4.Size = new System.Drawing.Size(75, 28);
            this.metroLink4.TabIndex = 5;
            this.metroLink4.Text = "Image";
            this.metroLink4.UseSelectable = true;
            this.metroLink4.Click += new System.EventHandler(this.metroLink4_Click);
            // 
            // metroLink3
            // 
            this.metroLink3.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroLink3.Location = new System.Drawing.Point(150, 0);
            this.metroLink3.Name = "metroLink3";
            this.metroLink3.Size = new System.Drawing.Size(75, 28);
            this.metroLink3.TabIndex = 4;
            this.metroLink3.Text = "View";
            this.metroLink3.UseSelectable = true;
            this.metroLink3.Click += new System.EventHandler(this.metroLink3_Click);
            // 
            // metroLink2
            // 
            this.metroLink2.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroLink2.Location = new System.Drawing.Point(75, 0);
            this.metroLink2.Name = "metroLink2";
            this.metroLink2.Size = new System.Drawing.Size(75, 28);
            this.metroLink2.TabIndex = 3;
            this.metroLink2.Text = "Edit";
            this.metroLink2.UseSelectable = true;
            this.metroLink2.Click += new System.EventHandler(this.metroLink2_Click);
            // 
            // metroLink1
            // 
            this.metroLink1.Dock = System.Windows.Forms.DockStyle.Left;
            this.metroLink1.Location = new System.Drawing.Point(0, 0);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(75, 28);
            this.metroLink1.TabIndex = 2;
            this.metroLink1.Text = "File";
            this.metroLink1.UseSelectable = true;
            this.metroLink1.Click += new System.EventHandler(this.metroLink1_Click);
            // 
            // metroPanel4
            // 
            this.metroPanel4.Controls.Add(this.metroPanel2);
            this.metroPanel4.Controls.Add(this.metroPanel1);
            this.metroPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel4.HorizontalScrollbarBarColor = true;
            this.metroPanel4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel4.HorizontalScrollbarSize = 10;
            this.metroPanel4.Location = new System.Drawing.Point(20, 88);
            this.metroPanel4.Name = "metroPanel4";
            this.metroPanel4.Size = new System.Drawing.Size(1197, 586);
            this.metroPanel4.TabIndex = 12;
            this.metroPanel4.VerticalScrollbarBarColor = true;
            this.metroPanel4.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel4.VerticalScrollbarSize = 10;
            // 
            // chart2
            // 
            chartArea20.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea20);
            this.chart2.Location = new System.Drawing.Point(102, 266);
            this.chart2.Name = "chart2";
            series20.ChartArea = "ChartArea1";
            series20.MarkerSize = 3;
            series20.Name = "Series1";
            this.chart2.Series.Add(series20);
            this.chart2.Size = new System.Drawing.Size(108, 98);
            this.chart2.TabIndex = 4;
            this.chart2.Text = "chart2";
            this.chart2.Click += new System.EventHandler(this.chart1_Click);
            // 
            // chart3
            // 
            chartArea21.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea21);
            this.chart3.Location = new System.Drawing.Point(102, 385);
            this.chart3.Name = "chart3";
            series21.ChartArea = "ChartArea1";
            series21.MarkerSize = 3;
            series21.Name = "Series1";
            this.chart3.Series.Add(series21);
            this.chart3.Size = new System.Drawing.Size(108, 98);
            this.chart3.TabIndex = 4;
            this.chart3.Text = "chart3";
            this.chart3.Click += new System.EventHandler(this.chart1_Click);
            // 
            // histogramEquilizationColorToolStripMenuItem
            // 
            this.histogramEquilizationColorToolStripMenuItem.Name = "histogramEquilizationColorToolStripMenuItem";
            this.histogramEquilizationColorToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.histogramEquilizationColorToolStripMenuItem.Text = "Histogram Equilization Color";
            this.histogramEquilizationColorToolStripMenuItem.Click += new System.EventHandler(this.histogramEquilizationColorToolStripMenuItem_Click);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.metroLabel4.Location = new System.Drawing.Point(1167, 0);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(30, 19);
            this.metroLabel4.TabIndex = 10;
            this.metroLabel4.Text = "Idle";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1237, 694);
            this.Controls.Add(this.metroPanel4);
            this.Controls.Add(this.metroPanel3);
            this.Name = "Form1";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.AeroShadow;
            this.Text = "Pixel Edit";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            this.metroPanel2.ResumeLayout(false);
            this.File.ResumeLayout(false);
            this.Edit.ResumeLayout(false);
            this.View.ResumeLayout(false);
            this.Image.ResumeLayout(false);
            this.Filters.ResumeLayout(false);
            this.Adjustments.ResumeLayout(false);
            this.Help.ResumeLayout(false);
            this.metroPanel3.ResumeLayout(false);
            this.metroPanel3.PerformLayout();
            this.metroPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTrackBar trackBar1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTrackBar trackBar2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTabControl tabControl1;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private MetroFramework.Controls.MetroContextMenu File;
        private System.Windows.Forms.ToolStripMenuItem openImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem1;
        private MetroFramework.Controls.MetroContextMenu Edit;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem1;
        private MetroFramework.Controls.MetroContextMenu View;
        private System.Windows.Forms.ToolStripMenuItem nextTabToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem previousTabToolStripMenuItem;
        private MetroFramework.Controls.MetroContextMenu Image;
        private System.Windows.Forms.ToolStripMenuItem rotateToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cWToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cCWToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem flipToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem horizontalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem verticalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem grayscaleToolStripMenuItem1;
        private MetroFramework.Controls.MetroContextMenu Filters;
        private System.Windows.Forms.ToolStripMenuItem blurToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem boxMeanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gaussian3X3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gaussian5X5ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sharpenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mediumToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem highToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem edgesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lowToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem embossToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem laplacianToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem laplacianOfGaussianToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem highToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem sobelHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sobelVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem prewittToolStripMenuItem;
        private MetroFramework.Controls.MetroContextMenu Adjustments;
        private System.Windows.Forms.ToolStripMenuItem histogramEquilizationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem invertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dilationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem erosionToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem x5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem x5ToolStripMenuItem1;
        private MetroFramework.Controls.MetroContextMenu Help;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem1;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Controls.MetroLink metroLink5;
        private MetroFramework.Controls.MetroLink metroLink4;
        private MetroFramework.Controls.MetroLink metroLink3;
        private MetroFramework.Controls.MetroLink metroLink2;
        private MetroFramework.Controls.MetroPanel metroPanel4;
        private MetroFramework.Controls.MetroLink metroLink6;
        private MetroFramework.Controls.MetroLink metroLink7;
        private System.Windows.Forms.ToolStripMenuItem skeletonizeToolStripMenuItem;
        private MetroFramework.Controls.MetroLink metroLink10;
        private MetroFramework.Controls.MetroLink metroLink9;
        private MetroFramework.Controls.MetroLink metroLink8;
        private MetroFramework.Controls.MetroToggle metroToggle3;
        private MetroFramework.Controls.MetroToggle metroToggle2;
        private MetroFramework.Controls.MetroToggle metroToggle1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.ToolStripMenuItem histogramEquilizationColorToolStripMenuItem;
        private MetroFramework.Controls.MetroLabel metroLabel4;
    }
}

